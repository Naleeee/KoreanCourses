


#include <iostream>

#define _USE_MATH_DEFINES
#include <cmath> 

#include "core.h"


int main()
{
	


}